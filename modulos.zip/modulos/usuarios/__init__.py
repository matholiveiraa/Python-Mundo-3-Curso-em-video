def lerpessoas(a):
    with open('cadastro.txt', 'r', encoding='utf-8') as arquivo:
        conteudo = arquivo.read()
        print(conteudo)

def cadastrar(b):
    with open('cadastro.txt', 'w', encoding='utf-8') as arquivo:
        while True:
            b = input("Digite nome e a idade em seguida, exemplo: ""ANA, 33"": ")
            arquivo.write(b)
            escolha = str(input("Quer continuar? [S/N] : ")).lower()
            if escolha in "Nn":
                break

def sair(c):
    if c == 3:
        print("-=" * 30)
        print("FIM DO PROGRAMA")
        print("-=" * 30)