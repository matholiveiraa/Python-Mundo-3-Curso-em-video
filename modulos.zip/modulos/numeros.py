import uteis

num = int(input("Digite o número: "))
fat = uteis.fatorial(num)
print(f"O fatorial de {num} é {fat}")
print(f"O dobro de {fat} é {uteis.dobro(fat)}")