# Crie um módulo chamado moeda.py
# funções aumentar(), diminuir(), dobro() e metade().
# Faça também um programa que importe esse módulo e use algumas dessas funções.

# Resumo:
# Preço analisado:
# Dobro do Preço:
# Metade do preço:
# Aumento
# Diminuir



def metade(n):
    return n / 2


def dobro(n):
    return n * 2


def aumentar(n):
    aumentar = float(input("Quanto você deseja aumentar sobre o valor %: ")) / 100
    a = n * aumentar

    b = (a + n)

    return round(b, 2)


def diminuir(n):
    diminuir = float(input("Quando você deseja diminuir sobre o valor %: "))
    d = diminuir / 100
    a = d * n

    b = (n - a)

    return round(b, 2)


def resumo(n):
    print("-=" * 30)
    print(f"Resumo")
    print("-=" * 30)
    print(f"Preço analisado: R${n}")
    print(f"Dobro: R${dobro(n)}")
    print(f"Metade: R${metade(n)}")
    print(f"Aumentado : R${aumentar(n)}")
    print(f"Diminuir: R${diminuir(n)}")





